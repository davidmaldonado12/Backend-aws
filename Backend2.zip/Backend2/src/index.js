import app from "./app";
import getConnection from '../database/database'; // Asegúrate de usar la ruta correcta

const main = async () => {
  await getConnection(); // Esto asegura que la conexión a la base de datos se establezca antes de iniciar el servidor
  app.listen(app.get("port"));
  console.log(`Server on port http://localhost:${app.get("port")}`);
};

main();
