import express from 'express';
import morgan from 'morgan';

import routes from '../routes/routes';

const app = express();

app.set('port', 5000);

// Middlewares
app.use(morgan('dev'));
app.use(express.json());

// Routes
app.use('/api/', routes)


export default app;