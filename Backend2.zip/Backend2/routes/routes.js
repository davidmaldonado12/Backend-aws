import {getController} from "../controllers/controller";
import { Router } from "express";

const router = Router();

router.get('/getUsers', getController);

export default router;