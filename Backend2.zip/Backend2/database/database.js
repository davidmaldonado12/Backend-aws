import config from "../src/config"; 
import mariadb from 'mariadb';


const pool = mariadb.createPool({
  host: config.ip,
  user: config.user,
  password: config.password,
  port: config.port,
  database: config.database
});

async function getConnection() {
  try {
      const connection = await pool.getConnection();
      console.log("Conexión a la base de datos establecida");
      return connection;
  } catch (error) {
      console.error("Error al conectar a la base de datos:", error);
      throw error;
  }
}

export default getConnection;