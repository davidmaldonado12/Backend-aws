import getConnection from "../database/database";

export const getController = async (req, res) => {
  const connection = await getConnection();
  const rows = await connection.query("SELECT * FROM usuarios2");
  res.json(rows);
}
